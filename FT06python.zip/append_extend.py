# -*- coding: utf-8 -*-
# @Time : 2022/3/9 15:28
# @Author : hhq
# @File : append_extend.py
def testF3(n):
    a = []
    i = 0
    val = n[i]
    del n[i]
    a.append(val)
    if len(n) != 0:
        i + 1
        a.extend(testF3(n))
    else:
        print('end')

c = testF3([3,2,5,1])
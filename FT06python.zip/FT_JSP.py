# -*- coding: utf-8 -*-
# @Time : 2021/12/18 21:15
# @Author : hhq
# @File : FT_JSP.py
import numpy as np
import random
import math
from Instance_ft06 import Process_time, O_num, J_num, M_num
from Object_for_FT import Object

JT = np.zeros(J_num)  # total time for each job
for i in range(J_num):
    for j in range(O_num[i]):
        Tij = [t for t in Process_time[i][j] if t != 0]
        JT[i] = sum(Tij)/len(Tij)  # 每个工件的每个工序平均加工时间
TC = sum(JT)  # 工件总加工时间
class Situation:  # evvironment
    def __init__(self, J_num, M_num, O_num, Process_time):
        self.J_num = J_num
        self.M_num = M_num
        self.O_num = O_num
        self.Process_time = Process_time
        self.TC = TC
        self.JT = JT
        self.CTK = [0 for i in range(M_num)]  # end time of the last operation in machine k
        self.OP = [0 for i in range(J_num)]  # operation number which has been finished of job
        self.UK = [0 for i in range(M_num)]  # utilization of each machine
        self.CRJ = [0 for i in range(J_num)]  # complete ratio of each job
        self.CTI = [0 for i in range(J_num)]  # end time of the last operation in each job


        # jobs that have been concerned
        self.Jobs = []
        for i in range(J_num):
            obj = Object(i)
            self.Jobs.append(obj)

        # machines that concerned
        self.Machines = []
        for i in range(M_num):
            obj = Object(i)
            self.Machines.append(obj)

        # update the basic data

    def scheduling(self, Job, Machine):  # 根据行动（选择的工件，机器），将加工工序所在工件、加工位置、加工时间开始、结束均存储起来

        # O_n = len(self.Jobs[Job].End)  # 目前已加工工件包含的工序数
        # print(Job, Machine,O_n)
        Idle = self.Machines[Machine].Idle  # 被选择的机器的闲置时间区间集合
        try:
            last_ot = self.CTI[Job]  # 上道工序加工结束时间
        except:
            last_ot = 0
        try:
            last_mt = self.CTK[Machine]  # 所在机器最后完工时间
        except:
            last_mt = 0
        Start_time = max(last_ot, last_mt)  # 开始时间
        PT = self.Process_time[Job][self.OP[Job]][Machine]  # 即将加工(目前工序号+1)的工序加工时间
        for i in range(len(Idle)):  # 多少个闲时间区间  Idle为空闲时段集合
            if Idle[i][1] - Idle[i][0] > PT:  # 大于该工序时间
                if Idle[i][0] > last_ot:
                    Start_time = Idle[i][0]
                    pass
                if Idle[i][0] < last_ot and Idle[i][1] - last_ot > PT:
                    Start_time = last_ot
                    pass
        end_time = Start_time + PT
        self.Machines[Machine]._add(Start_time, end_time, Job, PT)
        self.Jobs[Job]._add(Start_time, end_time, Machine, PT)
        self.Machines[Machine].idle_time()
        self.Jobs[Job].idle_time()
        print([Job,Machine])
        self.CTK[Machine] = max(self.Machines[Machine].End)
        self.CTI[Job] = max(self.Jobs[Job].End)  # 该工序加工结束的时间
        self.OP[Job] += 1  # 工件已加工的工序数量集合
        self.UK[Machine] = 0 if self.CTK[Machine] == 0 else sum(self.Machines[Machine].T) / self.CTK[Machine]  # 单台设备利用率 = 工件需要在机器加工时间之和/当前已结束工序的完工时间
        self.CRJ[Job] = sum(self.Jobs[Job].T) / self.JT[Job]  # 工件Job的完工率=已加工数/总工序数

    def Features(self):  # 同时反应局部信息和整体信息

        # 1设备平均利用率
        U_ave = sum(self.UK) / self.M_num  #

        # 2设备使用率标准差
        K = 0
        for uk in self.UK:
            K += np.square(uk - U_ave)
        U_std = np.sqrt(K/self.M_num)

        # 3平均工序完成率
        Ct = 0
        for i in range(self.J_num):
            Ct += sum(self.Jobs[i].T)
        CRO_ave = Ct / self.TC

        # 4平均工件工序完成率
        CRJ_ave = sum(self.CRJ)/self.J_num

        # 5工件工序完成率标准差
        K = 0
        for uk in self.CRJ:
            K += np.square(uk - CRJ_ave)
        CRJ_std = np.sqrt(K/self.J_num)

        # 6 工件剩余加工时间

        # 加工顺序
        # 每台机器加工信息
        # 机器与工件的组合表示加工状态，如11表示机器1加工了工件1，再次出现时表示加工了该工件的下道工序
        # 输入就用一维数据，之后尝试采用析取图以及卷积方式改变维度
        return U_ave, U_std, CRO_ave, CRJ_ave, CRJ_std

        # Composite dispatching rule 1
        # return Job,Machine

    def rule1(self):
        for i in range(self.J_num):
            if self.OP[i] < self.O_num[i]:
                Job_i = i
        # print(Job_i, self.OP[Job_i])
                for j in range(len(self.Process_time[Job_i][self.OP[Job_i]])):
                    if self.Process_time[Job_i][self.OP[Job_i]][j] > 0:
                        Machine = j
        # 选出剩余加工时间最长的工件
        remain_time = 0
        # Job_i = 0
        for i in range(self.J_num):
            if self.O_num[i] - self.OP[i] > 0:  # 存在剩余工件
                if self.JT[i] - sum(self.Jobs[i].T) > remain_time:
                    Job_i = i
                    remain_time = self.JT[i] - sum(self.Jobs[i].T)
        # print(Job_i, self.OP[Job_i])
                    for j in range(len(self.Process_time[Job_i][self.OP[Job_i]])):  # 该工件的工序在不同位置对应加工时间
                        if self.Process_time[Job_i][self.OP[Job_i]][j] > 0:
                            Machine = j

        return Job_i, Machine

    # Composite dispatching rule 2
    # return Job,Machine
    def rule2(self):
        # 选出加工剩余工序最多的工件
        remain_ope = np.zeros(self.J_num)
        for i in range(self.J_num):
            remain_ope[i] = self.O_num[i] - self.OP[i]
        Job_i = np.argmax(remain_ope)
        for j in range(len(self.Process_time[Job_i][self.OP[Job_i]])):
            if self.Process_time[Job_i][self.OP[Job_i]][j] > 0:
                Machine = j

        return Job_i, Machine

    # Composite dispatching rule 3
    def rule3(self):
        # 选出机器负载最小的机器及其对应的工件,
        for i in range(self.J_num):
            if self.OP[i] < self.O_num[i]:
                Job_i = i
        # print(Job_i, self.OP[Job_i])
                for j in range(len(self.Process_time[Job_i][self.OP[Job_i]])):
                    if self.Process_time[Job_i][self.OP[Job_i]][j] > 0:
                        Machine = j
        try:
            mac_load = np.zeros(self.M_num)
            for i in range(self.M_num):
                mac_load[i] = sum(self.Machines[i].T)
            Machine = np.argmin(mac_load)
            # 所有工件中在该机器加工的工序
            jobs_time = np.zeros(self.J_num)  # 所有在该台设备的加工时间工件集合
            index = []
            for j in range(self.J_num):
                # print((j, self.OP[j], Machine))
                if self.OP[j] < self.O_num[j]:
                    if self.Process_time[j][self.OP[j]][Machine] > 0:  # 在该台设备的加工时间大于0的工件
                        jobs_time[j] = self.CTI[j]  # 工件j的最近完工工序结束时间
                        index.append(j)  # 存储不为0的工件索引
            TIME = jobs_time[index[:]]  # 加工时间不为0的时间
            Job_i = index[np.argmin(TIME)]  # 最早结束工件索引
        except:  # 选出还未加工完全的机器
            for i in range(self.M_num):
                if len(self.Machines[i].T) < self.O_num[i]:
                    Machine = i
            for j in range(self.J_num):
                if self.OP[j]<self.O_num[j]:
                    if self.Process_time[j][self.OP[j]][Machine] > 0:
                        Job_i = j

        return Job_i, Machine

    # Composite dispatching rule 4
    def rule4(self):
        for i in range(self.J_num):
            if self.OP[i] < self.O_num[i]:
                Job_i = i
        # print(Job_i, self.OP[Job_i])
                for j in range(len(self.Process_time[Job_i][self.OP[Job_i]])):
                    if self.Process_time[Job_i][self.OP[Job_i]][j] > 0:
                        Machine = j
        end = self.JT[0]
        for i in range(self.J_num):
            if self.OP[i]<self.O_num[i]:
                if self.CTI[i]<end:
                    Job_i = i
                    end = self.CTI[i]
        # print(Job_i, self.OP[Job_i])
                    for j in range(len(self.Process_time[Job_i][self.OP[Job_i]])):
                        if self.Process_time[Job_i][self.OP[Job_i]][j] > 0:
                            Machine = j
        # 选出当前设备最先结束加工的工件
        return Job_i, Machine

    # Composite dispatching rule 5
    def rule5(self):
        for i in range(self.J_num):
            if self.OP[i] < self.O_num[i]:
                Job_i = i
        # print(Job_i, self.OP[Job_i])
                for j in range(len(self.Process_time[Job_i][self.OP[Job_i]])):
                    if self.Process_time[Job_i][self.OP[Job_i]][j] > 0:
                        Machine = j
        # 选出加工时间最短的工件
        total = self.JT[0]
        # Job_i = 0
        for i in range(self.J_num):
            if self.OP[i] < self.O_num[i]:
                if self.JT[i] < total:
                    Job_i = i
                    total = self.JT[i]
                    for j in range(len(self.Process_time[Job_i][self.OP[Job_i]])):
                        if self.Process_time[Job_i][self.OP[Job_i]][j] > 0:
                            Machine = j
        return Job_i, Machine

    # Composite dispatching rule 6
    # return Job,Machine
    def rule6(self):
        for i in range(self.J_num):
            if self.OP[i] < self.O_num[i]:
                Job_i = i
        # print(Job_i, self.OP[Job_i])
                for j in range(len(self.Process_time[Job_i][self.OP[Job_i]])):
                    if self.Process_time[Job_i][self.OP[Job_i]][j] > 0:
                        Machine = j
        # 选出加工时间最长的工件
        total = self.JT[0]
        # Job_i = 0
        for i in range(self.J_num):
            if self.OP[i] < self.O_num[i]:
                if self.JT[i] > total:
                    Job_i = i
                    total = self.JT[i]
                    for j in range(len(self.Process_time[Job_i][self.OP[Job_i]])):
                        if self.Process_time[Job_i][self.OP[Job_i]][j] > 0:
                            Machine = j
        return Job_i, Machine

    def rule7(self):
        for i in range(self.J_num):
            if self.OP[i] < self.O_num[i]:
                Job_i = i
        # print(Job_i, self.OP[Job_i])
                for j in range(len(self.Process_time[Job_i][self.OP[Job_i]])):
                    if self.Process_time[Job_i][self.OP[Job_i]][j] > 0:
                        Machine = j
        # 选出剩余加工时间最短的工件
        remain_time = self.JT[0]
        # Job_i = 0
        for i in range(self.J_num):
            if self.O_num[i] - self.OP[i] > 0:  # 存在剩余工件
                if self.JT[i] - sum(self.Jobs[i].T) < remain_time:
                    Job_i = i
                    remain_time = self.JT[i] - sum(self.Jobs[i].T)
                    for j in range(len(self.Process_time[Job_i][self.OP[Job_i]])):  # 该工件的工序在不同位置对应加工时间
                        if self.Process_time[Job_i][self.OP[Job_i]][j] > 0:
                            Machine = j

        return Job_i, Machine

    def rule8(self):
        for i in range(self.J_num):
            if self.OP[i] < self.O_num[i]:
                Job_i = i
        # print(Job_i, self.OP[Job_i])
                for j in range(len(self.Process_time[Job_i][self.OP[Job_i]])):
                      if self.Process_time[Job_i][self.OP[Job_i]][j] > 0:
                        Machine = j
        # 选出加工剩余工序最少的工件
        remain_ope = self.O_num[0]
        # Job_i = 0
        for i in range(self.J_num):
            if self.O_num[i] - self.OP[i] > 0:  # 存在剩余工件
                if self.O_num[i] - self.OP[i] < remain_ope:
                    Job_i = i
                    remain_ope = self.O_num[i] - self.OP[i]
                    for j in range(len(self.Process_time[Job_i][self.OP[Job_i]])):
                        if self.Process_time[Job_i][self.OP[Job_i]][j] > 0:
                            Machine = j

        return Job_i, Machine


    def reward(self, obs, obs_t, episode):
        #  obs[0-6]:设备平均利用率，设备利用率标准差、所有工序完成率、每个工件工序完成率平均值、平均工件工序完成率标准差、预估延迟程度(下一状态更好-小)、当前已延迟数量比例

        # print([Ta_t, Te_t, Ta_t1, Te_t1, U_t, U_t1])
        # rt = np.exp(Te_t)/np.exp(Te_t1) + np.exp(Ta_t)/np.exp(Ta_t1) + np.exp(U_t1)/np.exp(U_t)
        rt = (obs_t[0] - obs[0]) * (1 + np.exp(-1 * (obs_t[0] - obs[0]))) * 1 / (1 + np.exp(-1 * episode))
        return rt